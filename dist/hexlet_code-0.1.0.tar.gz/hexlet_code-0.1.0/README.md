### Hexlet tests and linter status:
[![Actions Status](https://github.com/KsyushaKI/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KsyushaKI/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/3332eade8e3c2c30fa8b/maintainability)](https://codeclimate.com/github/KsyushaKI/python-project-49/maintainability)


Projects demos:

[brain-even](https://asciinema.org/a/Vr7QviJzmEF9BfP6k7Hl5Oprk)

[brain-calc](https://asciinema.org/a/cSd0vSz6vDaZXB3hXIXXOHybv)

[brain-gcd](https://asciinema.org/a/tTF67NBTxHkA0Q28Batux0fV)

[brain-progression](https://asciinema.org/a/549682)

[brain-prime](https://asciinema.org/a/549705)
