### Hexlet tests and linter status:
[![Actions Status](https://github.com/KsyushaKI/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KsyushaKI/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/3332eade8e3c2c30fa8b/maintainability)](https://codeclimate.com/github/KsyushaKI/python-project-49/maintainability)


