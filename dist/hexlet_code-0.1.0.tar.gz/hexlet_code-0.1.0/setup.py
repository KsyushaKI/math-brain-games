# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['brain-games>=0.5.1,<0.6.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/KsyushaKI/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KsyushaKI/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/3332eade8e3c2c30fa8b/maintainability)](https://codeclimate.com/github/KsyushaKI/python-project-49/maintainability)\n\nДемонстрационный проект: https://asciinema.org/a/Vr7QviJzmEF9BfP6k7Hl5Oprk\n\n',
    'author': 'KsyushaKI',
    'author_email': 'oksanaakadem39@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
